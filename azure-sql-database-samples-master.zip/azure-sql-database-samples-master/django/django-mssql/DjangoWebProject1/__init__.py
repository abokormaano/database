"""
Package for DjangoWebProject1.
"""
