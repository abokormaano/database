# Using SQL Database from .NET (C#) 

## Requirements

### .NET Framework

.NET Framework is pre-installed with Windows. For Linux and Mac OS X you can download .NET Framework from the [Mono Project](http://www.mono-project.com/).

### A SQL Database

See the [getting started page](https://azure.microsoft.com/en-us/documentation/articles/sql-database-get-started/) to learn how to create a sample database and get your connection string.  
