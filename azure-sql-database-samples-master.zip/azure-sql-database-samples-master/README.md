# Azure SQL Database Code Samples
Azure SQL Database Samples and Reference Implementation Repository

Here we will cover samples for:

1. [PHP](https://github.com/Azure/azure-sql-database-samples/tree/master/php)

2. [Node.js](https://github.com/Azure/azure-sql-database-samples/tree/master/node.js)

4. [Python](https://github.com/Azure/azure-sql-database-samples/tree/master/python)

5. [Django](https://github.com/Azure/azure-sql-database-samples/tree/master/django)

6. [Ruby](https://github.com/Azure/azure-sql-database-samples/tree/master/ruby)

7. [Ruby on Rails](https://github.com/Azure/azure-sql-database-samples/tree/master/rubyonrails)

8. [Java](https://github.com/Azure/azure-sql-database-samples/tree/master/java)

9. [C#](https://github.com/Azure/azure-sql-database-samples/tree/master/c%23)

10. [T-SQL](https://github.com/Azure/azure-sql-database-samples/tree/master/t-sql/In-Memory)

# Questions
For questions please email meetb@microsoft.com or andrela@microsoft.com

